/* Olmike COT Mobile v3.0 — site-first (works when CFTC/GitHub blocked) */
(function () {
  "use strict";

  var SAMPLE = [
    {Symbol:"EURUSD",Commercial_Net:111225,NonCommercial_Net:-137573,Retail_Net:26348,Commercial_Pct:98,Retail_Pct:17,Date:"2026-10-13"},
    {Symbol:"GBPUSD",Commercial_Net:121444,NonCommercial_Net:-106964,Retail_Net:-14480,Commercial_Pct:96,Retail_Pct:4,Date:"2026-10-13"},
    {Symbol:"AUDUSD",Commercial_Net:106370,NonCommercial_Net:-117299,Retail_Net:10929,Commercial_Pct:98,Retail_Pct:12,Date:"2026-10-13"},
    {Symbol:"USDJPY",Commercial_Net:-48587,NonCommercial_Net:50207,Retail_Net:-1620,Commercial_Pct:39,Retail_Pct:28,Date:"2026-10-13"},
    {Symbol:"USDCAD",Commercial_Net:105613,NonCommercial_Net:-94765,Retail_Net:-10848,Commercial_Pct:60,Retail_Pct:19,Date:"2026-10-13"},
    {Symbol:"XAUUSD",Commercial_Net:-242531,NonCommercial_Net:207879,Retail_Net:34652,Commercial_Pct:52,Retail_Pct:67,Date:"2026-10-13"},
    {Symbol:"XAGUSD",Commercial_Net:-39442,NonCommercial_Net:22631,Retail_Net:16811,Commercial_Pct:83,Retail_Pct:43,Date:"2026-10-13"},
    {Symbol:"US30",Commercial_Net:-12457,NonCommercial_Net:8136,Retail_Net:4321,Commercial_Pct:20,Retail_Pct:73,Date:"2026-10-13"},
    {Symbol:"USOIL",Commercial_Net:-125335,NonCommercial_Net:100343,Retail_Net:24992,Commercial_Pct:75,Retail_Pct:50,Date:"2026-10-13"},
    {Symbol:"NATGAS",Commercial_Net:218838,NonCommercial_Net:-233578,Retail_Net:14740,Commercial_Pct:99,Retail_Pct:40,Date:"2026-10-13"},
    {Symbol:"BTCUSD",Commercial_Net:-2735,NonCommercial_Net:2534,Retail_Net:201,Commercial_Pct:0,Retail_Pct:48,Date:"2026-10-13"}
  ];

  var LS = "olmike_cot_v3";
  var rows = [];
  var deferredPrompt = null;

  function $(id) { return document.getElementById(id); }
  function clamp(v) {
    var n = Number(v);
    if (!isFinite(n)) return 50;
    return Math.max(0, Math.min(100, n));
  }
  function num(v) {
    var n = Number(String(v == null ? "" : v).replace(/,/g, ""));
    return isFinite(n) ? n : 0;
  }
  function fmt(n) {
    var x = Math.round(Number(n) || 0);
    return (x >= 0 ? "+" : "") + x.toLocaleString();
  }
  function status(msg) {
    var el = $("status");
    if (el) el.textContent = msg || "";
  }

  function bias(rPct, cPct) {
    var r = clamp(rPct), c = clamp(cPct);
    if (r <= 20 && c >= 70) return { t: "BULLISH", c: "bull", d: "Retail extreme short + Commercials extreme long" };
    if (r >= 80 && c <= 30) return { t: "BEARISH", c: "bear", d: "Retail extreme long + Commercials extreme short" };
    if (r <= 30 && c >= 60) return { t: "Mild Bullish", c: "bull", d: "Retail short + Commercials long" };
    if (r >= 70 && c <= 40) return { t: "Mild Bearish", c: "bear", d: "Retail long + Commercials short" };
    return { t: "NEUTRAL", c: "neut", d: "No clear extreme divergence" };
  }

  function parseCSV(text) {
    if (!text || typeof text !== "string") return [];
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    var lines = text.replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); });
    if (lines.length < 2) return [];
    var headers = lines[0].split(",").map(function (h) {
      return h.trim().replace(/^"|"$/g, "").toLowerCase();
    });
    function idx() {
      for (var i = 0; i < arguments.length; i++) {
        var j = headers.indexOf(arguments[i]);
        if (j >= 0) return j;
      }
      return -1;
    }
    var iS = idx("symbol", "market", "ticker");
    if (iS < 0) return [];
    var iC = idx("commercial_net", "comm_net");
    var iN = idx("noncommercial_net", "noncomm_net");
    var iR = idx("retail_net", "nonreportable_net");
    var iCp = idx("commercial_pct", "comm_pct");
    var iRp = idx("retail_pct");
    var iD = idx("date", "report_date");
    var out = [];
    for (var r = 1; r < lines.length; r++) {
      var p = lines[r].split(",");
      function cell(i) { return i < 0 ? "" : (p[i] || "").trim().replace(/^"|"$/g, ""); }
      var sym = cell(iS);
      if (!sym) continue;
      out.push({
        Symbol: sym,
        Commercial_Net: num(cell(iC)),
        NonCommercial_Net: num(cell(iN)),
        Retail_Net: num(cell(iR)),
        Commercial_Pct: iCp >= 0 ? clamp(cell(iCp)) : 50,
        Retail_Pct: iRp >= 0 ? clamp(cell(iRp)) : 50,
        Date: cell(iD)
      });
    }
    out.sort(function (a, b) { return a.Symbol.localeCompare(b.Symbol); });
    return out;
  }

  function save(list, meta) {
    try {
      localStorage.setItem(LS, JSON.stringify({ rows: list, meta: meta || {} }));
    } catch (e) {}
  }
  function loadCache() {
    try {
      var o = JSON.parse(localStorage.getItem(LS) || "null");
      if (o && o.rows && o.rows.length) return o;
    } catch (e) {}
    return null;
  }

  function setData(list, meta) {
    if (!list || !list.length) {
      status("No rows");
      return;
    }
    rows = list;
    save(list, meta);
    var sel = $("marketSelect");
    if (sel) {
      var prev = sel.value;
      sel.innerHTML = "";
      rows.forEach(function (r) {
        var o = document.createElement("option");
        o.value = r.Symbol;
        o.textContent = r.Symbol;
        sel.appendChild(o);
      });
      if (prev && rows.some(function (r) { return r.Symbol === prev; })) sel.value = prev;
    }
    renderList();
    renderMarket();
    var src = (meta && meta.source) || "local";
    var d = rows[0].Date || "—";
    status("Loaded " + rows.length + " markets · " + d + " · " + src);
    var rd = $("reportDate");
    if (rd) rd.textContent = d;
  }

  function renderMarket() {
    var sel = $("marketSelect");
    if (!sel || !rows.length) return;
    var r = null;
    for (var i = 0; i < rows.length; i++) if (rows[i].Symbol === sel.value) { r = rows[i]; break; }
    if (!r) return;
    var b = bias(r.Retail_Pct, r.Commercial_Pct);
    var bl = $("biasLabel");
    if (bl) { bl.textContent = b.t; bl.className = "bias " + b.c; }
    var br = $("biasReason");
    if (br) br.textContent = b.d;
    function set(id, t) { var e = $(id); if (e) e.textContent = t; }
    set("commNet", fmt(r.Commercial_Net));
    set("commRank", "Rank " + r.Commercial_Pct + "%");
    set("retailNet", fmt(r.Retail_Net));
    set("retailRank", "Rank " + r.Retail_Pct + "%");
    set("noncommNet", fmt(r.NonCommercial_Net));
  }

  function renderList() {
    var box = $("marketList");
    if (!box) return;
    box.innerHTML = "";
    rows.forEach(function (r) {
      var b = bias(r.Retail_Pct, r.Commercial_Pct);
      var div = document.createElement("div");
      div.className = "row-item";
      div.innerHTML = "<span><b>" + r.Symbol + "</b></span><span class=\"pill " + b.c + "\">" + b.t + "</span>";
      div.onclick = function () {
        $("marketSelect").value = r.Symbol;
        document.querySelectorAll(".tab").forEach(function (t) { t.classList.remove("active"); });
        var h = document.querySelector('.tab[data-tab="home"]');
        if (h) h.classList.add("active");
        showTab("home");
        renderMarket();
      };
      box.appendChild(div);
    });
  }

  function showTab(name) {
    ["home", "list", "data", "help"].forEach(function (t) {
      var el = $("tab-" + t);
      if (el) el.classList.toggle("hidden", t !== name);
    });
  }

  function httpGet(url, ms) {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, ms || 20000);
    return fetch(url, { cache: "no-store", signal: ctrl.signal })
      .then(function (res) {
        clearTimeout(t);
        return res;
      })
      .catch(function (err) {
        clearTimeout(t);
        if (err && err.name === "AbortError") throw new Error("timeout");
        throw err;
      });
  }

  /** PRIMARY: same-origin files shipped with the app */
  async function loadSiteData() {
    status("Loading site data…");
    // JSON first (full market list)
    try {
      var res = await httpGet("./cot-latest.json", 20000);
      var text = await res.text();
      if (res.status === 401 || res.status === 403)
        throw new Error("HTTP " + res.status + " — host is password-protected. Make the site public.");
      if (!res.ok) throw new Error("HTTP " + res.status);
      if (text.trim().charAt(0) === "<") throw new Error("Got HTML (file missing or login page)");
      var data = JSON.parse(text);
      var list = data.all && data.all.length ? data.all : (data.core || []);
      if (!list.length) throw new Error("empty JSON");
      setData(list, { source: "site cot-latest.json", at: new Date().toISOString() });
      return true;
    } catch (e1) {
      status("JSON: " + (e1.message || e1) + " — trying CSV…");
    }
    try {
      var res2 = await httpGet("./COT_Data.csv", 15000);
      var text2 = await res2.text();
      if (res2.status === 401 || res2.status === 403)
        throw new Error("HTTP " + res2.status + " — make site public");
      if (!res2.ok) throw new Error("HTTP " + res2.status);
      var parsed = parseCSV(text2);
      if (!parsed.length) throw new Error("CSV empty/parse fail");
      setData(parsed, { source: "site COT_Data.csv", at: new Date().toISOString() });
      return true;
    } catch (e2) {
      status("Site data failed: " + (e2.message || e2));
      return false;
    }
  }

  /** Optional: user GitHub raw URL only */
  async function loadGitHub() {
    var input = $("githubUrl");
    var url = (input && input.value.trim()) || "";
    if (!url) {
      status("Paste a full raw.githubusercontent.com/.../COT_Data.csv URL first");
      return;
    }
    if (url.indexOf("https://github.com/") === 0 && url.indexOf("/blob/") > 0) {
      url = url.replace("https://github.com/", "https://raw.githubusercontent.com/").replace("/blob/", "/");
      if (input) input.value = url;
    }
    status("Fetching GitHub…");
    try {
      var res = await httpGet(url, 25000);
      var text = await res.text();
      if (!res.ok) throw new Error("HTTP " + res.status);
      if (text.trim().charAt(0) === "<") throw new Error("HTML not CSV — wrong/private URL");
      var parsed = parseCSV(text);
      if (!parsed.length) throw new Error("No valid CSV rows");
      setData(parsed, { source: "GitHub", url: url, at: new Date().toISOString() });
    } catch (e) {
      status("GitHub failed: " + (e.message || e));
    }
  }

  function loadFile(file) {
    if (!file) return;
    status("Reading " + file.name + "…");
    var reader = new FileReader();
    reader.onload = function () {
      var parsed = parseCSV(String(reader.result || ""));
      if (!parsed.length) {
        status("Parse failed — need header with Symbol, Commercial_Pct, Retail_Pct…");
        return;
      }
      setData(parsed, { source: "file:" + file.name, at: new Date().toISOString() });
    };
    reader.onerror = function () { status("Could not read file"); };
    reader.readAsText(file);
  }

  function wire() {
    document.querySelectorAll(".tab").forEach(function (btn) {
      btn.onclick = function () {
        document.querySelectorAll(".tab").forEach(function (t) { t.classList.remove("active"); });
        btn.classList.add("active");
        showTab(btn.getAttribute("data-tab"));
      };
    });
    var sel = $("marketSelect");
    if (sel) sel.onchange = renderMarket;

    var b1 = $("btnSite");
    if (b1) b1.onclick = function () {
      b1.disabled = true;
      loadSiteData().finally(function () { b1.disabled = false; });
    };
    var b2 = $("btnGitHub");
    if (b2) b2.onclick = function () {
      b2.disabled = true;
      loadGitHub().finally(function () { b2.disabled = false; });
    };
    var b3 = $("btnSample");
    if (b3) b3.onclick = function () {
      setData(SAMPLE.slice(), { source: "sample" });
    };
    var f = $("csvFile");
    if (f) f.onchange = function (e) {
      loadFile(e.target.files && e.target.files[0]);
    };

    function install() {
      if (!deferredPrompt) {
        alert("iPhone: Safari → Share → Add to Home Screen\nAndroid: Chrome → Install app / Add to Home screen");
        return;
      }
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(function () {
        deferredPrompt = null;
        var banner = $("installBanner");
        if (banner) banner.classList.remove("show");
      });
    }
    var bi = $("btnInstall");
    if (bi) bi.onclick = install;
    var bb = $("btnInstallBanner");
    if (bb) bb.onclick = install;
  }

  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault();
    deferredPrompt = e;
    var banner = $("installBanner");
    if (banner) banner.classList.add("show");
  });

  document.addEventListener("DOMContentLoaded", function () {
    wire();
    // 1) cache  2) site files  3) sample
    var cache = loadCache();
    if (cache) {
      setData(cache.rows, cache.meta || { source: "device cache" });
      status("Cached data — tap Load site data to refresh");
    }
    loadSiteData().then(function (ok) {
      if (!ok && !cache) setData(SAMPLE.slice(), { source: "sample" });
    });
  });
})();
